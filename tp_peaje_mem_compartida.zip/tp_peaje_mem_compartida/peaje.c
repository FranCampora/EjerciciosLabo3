#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <time.h>
#include <unistd.h>
#include <sys/shm.h>

#include "def.h"
#include "global.h"
#include "semaforo.h"
#include "archivos.h"
#include "funciones.h"
#include "clave.h"
#include "memoria.h"

int main(int argc, char *argv[])
{
    int id_semaforo;

    int id_memoria;
    int i;
    int buffer;
    int CANTIDAD_DE_VIAS;
    int tiempoEspera;
    char nombreArchivo[LARGO];
    char szBuffer[LARGO];
    int actualVia;

    
    
    via *memoria = NULL;
    

    /*ingreso de vias */
    if(argc != 2)
		{
			printf("Ingrese LA CANTIDAD DE VIAS DEL PEAJE\n");
			exit(1);
		}
    
    CANTIDAD_DE_VIAS = atoi(argv[1]);
    if (CANTIDAD_DE_VIAS <= 0)
    {
        printf("La cantidad de vias debe ser un número positivo.\n");
        exit(1);
    }
    

    id_semaforo = creo_semaforo();
    inicia_semaforo(id_semaforo, VERDE);

    memoria = (via*)creo_memoria(sizeof(via)*CANTIDAD_DE_VIAS, &id_memoria);

    /*creo el total de las vias q le pase pre while*/
    for ( i = 0; i < CANTIDAD_DE_VIAS; i++)
    {
        memoria[i].cantidadAutos = 0;
        memoria[i].numeroVia = i+1;
    }
    actualVia = 0;


    srand(time(NULL));
    memset(nombreArchivo,0x00,sizeof(nombreArchivo));
    sprintf(nombreArchivo, "peajesLiberados.dat");

    /*logica de peaje y autos
    
    1. asgino la cantidad de vias que quiero
    2. la cantidad de vias la tengo que asginar de alguna manera pero no se como en def.h
    3. creo el file de peajesLiberados.dat
    4. empieza el bucle
    5. leo el archivo peajesLiberados.dat, si hay algo escrito, lo guardo en una variable buffer
    6. empieza el for  que va a pasar por todas las vias
    7. imprimo por pantalla la cantidad de autos en cada via
    8. si alguna via tiene mayor a 10 autos, reseteo la cantidad de autos a 0, y escribo en el archivo peajesLiberados.dat que se libero un peaje, osea sumo 1
    9. levanto el semaforo de peaje para que los autos puedan seguir entrando a las vias

    en autos
    1. paso por todas las vias hasta encontrar la que tiene menor cantidad de autos
    2. a esa le sumo 1 auto e imprimo por pantalla a que via se sumo el auto
    3. levanto el semaforo de autos para que peaje pueda seguir leyendo

    
    
    */

    printf("PEAJE listo. Enter para empezar.\n");
    getchar();

    while (1)
    {
        espera_semaforo(id_semaforo);

        

        /*leo el archivo  para saber la cantidad de peajes liberados*/
        memset(szBuffer,0x00,sizeof(szBuffer));
        if (abrirArchivo(nombreArchivo,"r") == TRUE)
        {
            if (leerArchivo(szBuffer) == TRUE)
            {
            sscanf(szBuffer, "%d\n", &buffer);
            printf("Peajes liberados por ahora son: %d\n", buffer);
            }
            cerrarArchivo();
        }
        
        /*RECORRO LAS VIAS*/

        for (i = 0; i < CANTIDAD_DE_VIAS; i++)
        {
            printf("Via %d tiene %d autos en cola\n", memoria[i].numeroVia, memoria[i].cantidadAutos);
            
            }
        
        if (memoria[actualVia].cantidadAutos > LIMITE_LIBERACION)/*10 ES el limite*/
        {
            printf("Via %d paso un lote de vehiculos\n", memoria[actualVia].numeroVia);
            memoria[actualVia].cantidadAutos = 0;

            /*buffer++;*/
            memset(szBuffer,0x00,sizeof(szBuffer));
            sprintf(szBuffer, "%d\n", buffer+1);

            if (abrirArchivo(nombreArchivo,"w") == TRUE)
            {
                
                escribirArchivo(szBuffer);
                cerrarArchivo();
            }
            printf("Peajes liberados por ahora son: %d\n", buffer);
            
        }
        else if (memoria[actualVia].cantidadAutos > 0)
        {
            printf("Via %d paso un vehiculo\n", memoria[actualVia].numeroVia);
            memoria[actualVia].cantidadAutos--;
        }
    
        actualVia++;
        if (actualVia >= CANTIDAD_DE_VIAS)
        {
            actualVia = 0;
        }

        levanta_semaforo(id_semaforo);
        tiempoEspera = (rand() % (MAX_TIEMPO_PEAJE - MIN_TIEMPO_PEAJE)) + MIN_TIEMPO_PEAJE;
        usleep(tiempoEspera*1000);
    }

    shmdt ((char *)memoria);
	shmctl (id_memoria, IPC_RMID, (struct shmid_ds *)NULL);


    return 0;
}

