#include <stdio.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <time.h>
#include <unistd.h>
#include <sys/shm.h>
#include <errno.h>
#include <stdlib.h>
#include <pthread.h>

#include "def.h"
#include "global.h"
#include "semaforo.h"
#include "archivos.h"
#include "funciones.h"
#include "clave.h"
#include "memoria.h"
#include "mensajes.h"
#include "threads.h"

int main(int argc, char *argv[])
{
    int i;
    
    
    int num_equipo;
    int id_cola_mensajes;
    int goles_finales;
    int partido_terminado;
    int numero_random_generado;
    int numero_ingresado;
    char szBuffer[LARGO];
    
    int umbral_equipos[MAX_EQUIPO + 1];

    
    mensaje msg;

    memset(umbral_equipos,    0x00,    sizeof(umbral_equipos));
    memset(szBuffer, 0x00, sizeof(szBuffer));
    memset(&msg,     0x00, sizeof(msg));

    id_cola_mensajes = creo_id_cola_mensajes();

    goles_finales = 0;
    partido_terminado = FALSE;

    srand(time(NULL));

    crearArchivoSincronismo(FILE_SINCRONISMO,1);
    borrar_mensajes(id_cola_mensajes);

    printf("PROCESO cancha LISTA PARA EMPEZAR. Enter para empezar...");
    getchar();


    recibir_mensaje(id_cola_mensajes,MSG_CANCHA,&msg);
    if (msg.int_evento == EVT_INICIO)
    {
        sscanf(msg.char_mensaje, "%d|%d", &umbral_equipos[1],&umbral_equipos[2]);
        printf("Cancha: equipo 1 umbral%d. equipo 2 umbral %d\n", umbral_equipos[1],umbral_equipos[2]);

        /*envia evento inicio ack a los 2 equipos*/
        for ( i = 0; i < MAX_EQUIPO; i++)
        {
            memset(szBuffer, 0x00, sizeof(szBuffer));
            sprintf(szBuffer, "%d", i + 1);
            enviar_mensaje(id_cola_mensajes, MSG_EQUIPO + (i + 1), MSG_CANCHA, EVT_INICIO_ACK, szBuffer);
        }
        printf("Cancha: inicio enviado a los %d equipos. Partido comenzando.\n", MAX_EQUIPO);
    }
        
    
    
    while (partido_terminado == FALSE)
    {
        recibir_mensaje(id_cola_mensajes,MSG_CANCHA,&msg);
        switch (msg.int_evento)
        {
            
            /*case EVT_INICIO:
                sscanf(msg.char_mensaje, "%d", &num_equipo);
                printf("Cancha: recibio inicio del equipo %d\n", num_equipo);
                memset(szBuffer, 0x00, sizeof(szBuffer));
                sprintf(szBuffer, "%d", num_equipo);
                enviar_mensaje(id_cola_mensajes, MSG_EQUIPO + num_equipo, MSG_CANCHA, EVT_INICIO_ACK, szBuffer);
                break;*/
            case EVT_TIRO:
                    /*recibo tiro ingresado por uno de los equipos y calculo el random*/
                numero_random_generado = devolverNumAleatorio(DESDE,HASTA);
                printf("El numero random generado es %d\n",numero_random_generado);

                memset(szBuffer, 0x00, sizeof(szBuffer));
                sscanf(msg.char_mensaje,"%d|%d",&num_equipo,&numero_ingresado);
                
                printf("Cancha: equipo %d ingreso %d | random = %d\n",
                num_equipo, numero_ingresado, numero_random_generado);

                memset(szBuffer, 0x00, sizeof(szBuffer));
                sprintf(szBuffer, "%d", num_equipo);

                /*comparo los numero para saber si es gol*/
                if (numero_random_generado == 3)
                {
                    if (numero_ingresado == 3)
                    {
                        printf("El equipo %d metio un GOL de juagada\n",num_equipo);
                        /* envio mensaje de gol al equipo */
                        memset(szBuffer, 0x00, sizeof(szBuffer));
                        sprintf(szBuffer, "%d", num_equipo);
                        enviar_mensaje(id_cola_mensajes, MSG_EQUIPO + num_equipo, MSG_CANCHA, EVT_GOL, szBuffer);
                    
                    }else if(numero_ingresado == 4)
                    {
                        printf("El equipo %d metio un GOL\n",num_equipo);
                        /* envio mensaje de gol al equipo */
                        memset(szBuffer, 0x00, sizeof(szBuffer));
                        sprintf(szBuffer, "%d", num_equipo);
                        enviar_mensaje(id_cola_mensajes, MSG_EQUIPO + num_equipo, MSG_CANCHA, EVT_GOL, szBuffer);
                    }else if (numero_ingresado == 5)
                    {
                        printf("El equipo %d hizo un tiro libre\n",num_equipo);
                        /* envio mensaje de gol al equipo */
                        memset(szBuffer, 0x00, sizeof(szBuffer));
                        sprintf(szBuffer, "%d", num_equipo);
                        enviar_mensaje(id_cola_mensajes, MSG_EQUIPO + num_equipo, MSG_CANCHA, EVT_TIRO_LIBRE, szBuffer);
                    
                    }else
                    {
                        printf("eL Equipo %d, le pego afuera\n",num_equipo);
                        memset(szBuffer, 0x00, sizeof(szBuffer));
                        sprintf(szBuffer, "%d", num_equipo);
                        enviar_mensaje(id_cola_mensajes,MSG_EQUIPO+num_equipo,MSG_CANCHA,EVT_FUERA,szBuffer);
                    }
                }else/*osea q random es 4 o 5*/
                {
                    if (numero_ingresado == 3)
                    {
                        printf("El equipo %d LE PEGO AL PALO\n",num_equipo);
                        /* envio mensaje de gol al equipo */
                        memset(szBuffer, 0x00, sizeof(szBuffer));
                        sprintf(szBuffer, "%d", num_equipo);
                        enviar_mensaje(id_cola_mensajes, MSG_EQUIPO + num_equipo, MSG_CANCHA, EVT_PALO, szBuffer);
                    
                    }else if (numero_ingresado == 4)
                    {
                        printf("El equipo %d LE PEGO AFUERA\n",num_equipo);
                        /* envio mensaje de gol al equipo */
                        memset(szBuffer, 0x00, sizeof(szBuffer));
                        sprintf(szBuffer, "%d", num_equipo);
                        enviar_mensaje(id_cola_mensajes, MSG_EQUIPO + num_equipo, MSG_CANCHA, EVT_FUERA, szBuffer);
                    
                    }else if (numero_ingresado == 5)
                    {
                        printf("El equipo %d HIZO UN LATERAL\n",num_equipo);
                        /* envio mensaje de gol al equipo */
                        memset(szBuffer, 0x00, sizeof(szBuffer));
                        sprintf(szBuffer, "%d", num_equipo);
                        enviar_mensaje(id_cola_mensajes, MSG_EQUIPO + num_equipo, MSG_CANCHA, EVT_LATERAL, szBuffer);
                    
                    }else
                    {
                        printf("eL Equipo %d, le pego afuera\n",num_equipo);
                        memset(szBuffer, 0x00, sizeof(szBuffer));
                        sprintf(szBuffer, "%d", num_equipo);
                        enviar_mensaje(id_cola_mensajes,MSG_EQUIPO+num_equipo,MSG_CANCHA,EVT_FUERA,szBuffer);
                    }
                    
                }
                break;
                
            case EVT_FIN:
                printf("HUBO GANADOR\n");
                memset(szBuffer,0x00,sizeof(szBuffer));
                sscanf(msg.char_mensaje,"%d|%d",&num_equipo,&goles_finales);
                printf("El equipo %d GANO llego a la cantidad %d de goles de umbral\n",num_equipo,goles_finales);
                

                /*avisarle al otro para q corte*/
                memset(szBuffer, 0x00, sizeof(szBuffer));
                sprintf(szBuffer, "%d", (MAX_EQUIPO + 1) - num_equipo);
                enviar_mensaje(id_cola_mensajes,MSG_EQUIPO+((MAX_EQUIPO+1)-num_equipo),MSG_CANCHA,EVT_FIN,szBuffer);/*buscar forma mas simple para q funque*/
                partido_terminado = TRUE;
                break;    
            default:
                break;
        }

    }
    printf("Cancha: esperando que el equipo perdedor procese el fin...\n");
    sleep(5);
    
    borrar_cola_de_mensajes(id_cola_mensajes);

    return 0;
}
