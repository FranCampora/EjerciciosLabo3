#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include <sys/ipc.h>
#include <sys/sem.h>
#include "unistd.h"
#include "semaforo.h"
#include "clave.h"
#include "memoria.h"



/*funcion que crea el semaforo*/
int creo_semaforo()
{
	key_t clave = creo_clave();
	int id_semaforo = semget(clave, 1, 0600|IPC_CREAT); /*funcion nativa del so para semafroro */
	/*PRIMER PARAMETRO ES LA CLAVE, EL SEGUNDO CANT SEMAFORO, EL TERCERO son flags: 0600 permisos LO UTILIZA CUALQUIERA, IPC ES si no existe el sem crealo, si existe devolve id*/
	if(id_semaforo == -1)
	{
		printf("Error: no puedo crear semaforo\n");
		exit(0);
	}
	return id_semaforo;
}

/*inicia el semaforo*/
void inicia_semaforo(int id_semaforo, int valor)
{
	semctl(id_semaforo, 0, SETVAL, valor);/*funcion para config el semaforo q ya existe*/
}
/*SETVAL es asignarle un valor al semaforo*/

/*levanta el semaforo*/
void levanta_semaforo(int id_semaforo)
{
	struct sembuf operacion;
	printf("Levanta SEMAFORO \n");
	operacion.sem_num = 0;
	operacion.sem_op = 1; /*incrementa el semaforo en 1*/
	operacion.sem_flg = 0;
	semop(id_semaforo,&operacion,1);
}

/*espera semaforo*/
void espera_semaforo(int id_semaforo)
{
	struct sembuf operacion;
	printf("Espera SEMAFORO \n");
	operacion.sem_num = 0;
	operacion.sem_op = -1; /*decrementa el semaforo en 1*/
	operacion.sem_flg = 0;
	semop(id_semaforo,&operacion,1);

}
